#!/bin/bash
##Script for DB backups using mongodump
# Creating a log director

year=$(date +%Y)
month=$(date +%b)
DAY=$(date +%Y-%m-%d)
DIR=/data/backups/backup_$DAY
FILEEXTN=mongodump-$(date +$DAY\_%H-%M)
BACKUPDIR=$DIR/$FILEEXTN

echo '****************************'
echo 'Backup Started'

#Make sure teh backp dir exists"
mkdir -p $BACKUPDIR

#DB backup using mongodump

mongodump --username=korebackup  --password='Kore@123' -o $BACKUPDIR  --authenticationDatabase admin

df -h

#Zip the backup
cd $DIR
zip -r $FILEEXTN.zip $FILEEXTN

#Remove the original directory after zipping
rm -rf $BACKUPDIR

echo ' Backup completed '
echo '****************************'

## Script to upload the latest backup of the day to S3

echo '****************************'
echo 'Upload Started'


DIR=/data/backups/backup_$DAY
cd $DIR
BKUPFILE=$(ls -1rt *.zip | tail -1)

#Uplod the latest backup to S3
#/usr/bin/s3cmd put -v $BKUPFILE s3://DBbackupmongo/$month/QA1/
echo $BKUPFILE

aws s3 cp $BKUPFILE s3://DBbackupmongo/$year/$month/QABOTS/$BKUPFILE

exitcode="$?"

echo "exit code is $exitcode"

if [ $exitcode  -gt 0 ];then
echo "upload failed"
exit 1
fi

echo "Upload done"

#echo "removing old backup once the upload is completed"
rm -rf $BKUPFILE


echo ' Upload completed '
echo '****************************'

